package com.example.foodplanner.model.RemoteDataSource;

import android.content.Context;

import com.example.foodplanner.model.Pojos.AreasPojo;
import com.example.foodplanner.model.Pojos.CategoriesPojo;
import com.example.foodplanner.model.Pojos.IngeriedientPojo;
import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import hu.akarnokd.rxjava3.retrofit.RxJava3CallAdapterFactory;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient implements RemoteSource{
    public static final String url="https://www.themealdb.com/api/json/v1/1/";
    UserService  userService;

    private static ApiClient instance = null;

    public ApiClient (Context context) {

        File cacheDirectory = new File(context.getCacheDir(), "offline_cache_directory");
        Cache cache = new Cache(cacheDirectory,100 *1024 * 1024);

        OkHttpClient okHttpClient = new OkHttpClient
                .Builder().cache(cache).build();

        Retrofit.Builder retrofitB = new Retrofit.Builder()
                .baseUrl(url)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava3CallAdapterFactory.create());

        Retrofit retrofit = retrofitB.build();

        userService = retrofit.create(UserService.class);


    }

    public static ApiClient getInstance(Context context){

        if (instance == null){
            instance = new ApiClient(context);
        }

        return instance;
    }

    @Override
    public void getRandomMeal(NetworkDelegate networkDelegate) {
        List<ProductsPOJO> list=new ArrayList<>(); //Creates an empty list to store the fetched meals.
        Flowable<ProductsPOJO> mealModelResponseSingle= userService.getRandomMeal(); // Using the mealService instance which returns a Flowable emitting MealModelResponse objects.
        mealModelResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .repeat(10) //Repeats the API call 10 times. This may be useful if you want to retry the request multiple times.
                .doOnNext(e-> list.addAll(e.getMeals()))
                .doOnComplete(()->networkDelegate.onSuccessMeals(list))
                .subscribe();
    }

    @Override
    public void getAllCategories(NetworkDelegate networkDelegate) {
        Single<CategoriesPojo> categoryResponseSingle= userService.getAllCategories();
        categoryResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessCategories(item.getCategories()));
    }

    @Override
    public void getAllAreas(NetworkDelegate networkDelegate) {
        Single<AreasPojo> countryResponseSingle= userService.getAllAreas();
        countryResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessArea(item.getArea()));

    }

    @Override
    public void getAllIngredients(NetworkDelegate networkDelegate) {
        Single<IngeriedientPojo> ingeriedientPojoSingle= userService.getAllIngredients();
        ingeriedientPojoSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessIngeriedient(item.getIngerdiants()));
    }

    @Override
    public void getMealByFirstChar(NetworkDelegate networkDelegate, String name) {
        Single<ProductsPOJO> mealModelResponseSingle= userService.getMealByFirstChar(name);
        mealModelResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessMeals(item.getMeals()));

    }

    @Override
    public void getMealsByCategory(NetworkDelegate networkDelegate, String category) {
        Single<ProductsPOJO>  productsPOJOSingle= userService.getMealsByCategory(category);
        productsPOJOSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessMeals(item.getMeals()));
    }

    @Override
    public void getMealsByArea(NetworkDelegate networkDelegate, String country) {
        Single<ProductsPOJO> countryResponseSingle= userService.getMealsByArea(country);
        countryResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessMeals(item.getMeals()));


    }

    @Override
    public void getMealsByIngredient(NetworkDelegate networkDelegate, String ingredient) {
        Single<ProductsPOJO> ingeriedientPojoSingle= userService.getMealsByIngredient(ingredient);
        ingeriedientPojoSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessMeals(item.getMeals()));

    }

    @Override
    public void getMealByName(NetworkDelegate networkDelegate, String name) {
        Single<ProductsPOJO> mealModelResponseSingle= userService.getMealByName(name);
        mealModelResponseSingle.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .onErrorComplete()
                .subscribe(item -> networkDelegate.onSuccessMeals(item.getMeals()));

    }
}
