package com.example.foodplanner.mealPreparation.view;

public class MealPreparationAdapter {
}
