package com.example.foodplanner.authantication.signin.view;

import android.content.Context;

public interface SignInInterface {
      void signInWithEmailAndPassword(String email, String password);
}
