package com.example.foodplanner.mealPreparation.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.foodplanner.R;

public class MealPreparation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_preparation);
    }
}