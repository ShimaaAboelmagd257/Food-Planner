package com.example.foodplanner.model.LocalDataSource;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.foodplanner.model.Pojos.ProductsPOJO;


@Database(entities = {ProductsPOJO.class},   version = 1)
public abstract class ProductDataBase extends RoomDatabase{

    public static ProductDataBase instance = null;
    public abstract DataAcessObjectDAO Dao() ; // to access the data base operation methods

    public static synchronized ProductDataBase getInstance(Context context){
        if(instance == null){

            instance = Room.databaseBuilder(context.getApplicationContext() ,ProductDataBase.class , "Meals" )
                    .fallbackToDestructiveMigration().build();

        }

        return instance;
    }
}
