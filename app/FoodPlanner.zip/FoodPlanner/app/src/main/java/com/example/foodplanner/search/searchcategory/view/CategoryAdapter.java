package com.example.foodplanner.search.searchcategory.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.foodplanner.R;
import com.example.foodplanner.authantication.signup.view.SignUpActivity;
import com.example.foodplanner.mealPreparation.view.MealPreparation;
import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.myViewHolder> {

    public static String SKIP ;
    private final Context context;
    private List<ProductsPOJO> list;
    public static final String TAG = "RECYCLER";

    public static class myViewHolder extends RecyclerView.ViewHolder{
        CardView cardView;
        ImageView mealImage;
        TextView mealName;
        View itemview;
        ImageButton favoriteImage;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            itemview = itemView;
            cardView = itemView.findViewById(R.id.cardCategory);
            mealImage = itemView.findViewById(R.id.imageCategory);
            mealName = itemView.findViewById(R.id.categoryName);
            favoriteImage = itemView.findViewById(R.id.mealFav);

        }
    }

    public CategoryAdapter(Context context, List<ProductsPOJO> list, CategorySection categorySection) {
        this.context = context;
        this.list = list;
    }


    public void setList(List<ProductsPOJO> categorylist) {
        this.list = categorylist;
    }


    @NonNull
    @Override
    public CategoryAdapter.myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.mealitem,parent,false);
        CategoryAdapter.myViewHolder viewHolder = new  CategoryAdapter.myViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryAdapter.myViewHolder holder, int position) {


        ProductsPOJO item = list.get(position);
        // Set the meal name to the TextView
        holder.mealName.setText(list.get(position).getStrMeal());

        // Load the meal image using Glide
        Glide.with(context).load(list.get(position).getStrMealThumb())
                .apply(new RequestOptions().override(holder.mealImage.getWidth(),holder.mealImage.getHeight()))
                .placeholder(R.drawable.ic_launcher_background)
                .error(R.drawable.ic_launcher_foreground)
                .into(holder.mealImage);


        // Set an OnClickListener for the card view
        holder.cardView.setOnClickListener(v -> navigateToItemPage(list.get(position).getStrMeal()));

        // Set an OnClickListener for the favorite button
        holder.favoriteImage.setOnClickListener(v -> handleFavoriteClick(item));
    }

    private void navigateToItemPage(String mealName) {
        Intent intent = new Intent(context, MealPreparation.class);
        intent.putExtra("MEAL_NAME", mealName);
        context.startActivity(intent);
    }

    private void handleFavoriteClick(ProductsPOJO item) {
        if (SKIP.equals("skip")) {
            showSignUpAlertDialog();
        } else {
            item.setFavorite(true);
            item.setNameDay("Not");
          //  onCategoriesClickListenterInterface.addToFavoriteOnClick(item);
        }
    }




    private void showSignUpAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Do you want to sign up in the application?");
        builder.setTitle("Alert!");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes, Signup", (dialog, which) -> {
            Intent intent = new Intent(context, SignUpActivity.class);
            context.startActivity(intent);
            ((Activity) context).finish();
        });

        builder.setNegativeButton("No, thanks", (dialog, which) -> dialog.cancel());


        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }



    @Override
    public int getItemCount() {
        return list.size();
    }




}
