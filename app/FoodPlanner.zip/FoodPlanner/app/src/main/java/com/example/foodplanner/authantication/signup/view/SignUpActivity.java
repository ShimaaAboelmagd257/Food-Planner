package com.example.foodplanner.authantication.signup.view;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foodplanner.R;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;
import com.example.foodplanner.homeforyou.HomeForYou;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;


public class SignUpActivity extends AppCompatActivity implements SignUpInterface{

    EditText name , email , password , confirmpass ;
    Button next , skip ;
    private boolean showOneTapUI = true;
    private FirebaseAuth mAuth;

    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    public static String SKIP ;
    public static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})";
    SignUpInterface  signupInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        name = findViewById(R.id.nameID);
        email = findViewById(R.id.EmaiID);
        password = findViewById(R.id.PasswordID);
        confirmpass = findViewById(R.id.confirmPasswordID);
        next = findViewById(R.id.nextBtnID);
        skip = findViewById(R.id.backBtnID);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this,HomeForYou.class);
                startActivity(intent);
                signupWithCreateEmailClick();
                Toast.makeText(SignUpActivity.this, " SignUp Succeded", Toast.LENGTH_SHORT).show();

            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this, HomeForYou.class);
                startActivity(intent);
            }
        });
    }
    public void signupWithCreateEmailClick() {

        String nameStr = name.getText().toString();
        String emailStr = email.getText().toString();
        String passwordStr = password.getText().toString();
        String confirmPassStr = confirmpass.getText().toString();

        if (isEmpty(nameStr) || isEmpty(emailStr) || isEmpty(passwordStr) || isEmpty(confirmPassStr))
            Toast.makeText(this, "You should fill all data", Toast.LENGTH_SHORT).show();
         else if (!passwordStr.equals(confirmPassStr))
            Toast.makeText(this, "Password and confirmPassword don’t match", Toast.LENGTH_SHORT).show();
         else if (!emailStr.matches(EMAIL_PATTERN))
            Toast.makeText(this, "Email is invalid", Toast.LENGTH_SHORT).show();
         else if (!passwordStr.matches(PASSWORD_PATTERN))
            Toast.makeText(this, "Password is invalid", Toast.LENGTH_SHORT).show();
         else
           createUserPojo( nameStr, emailStr, passwordStr);
    }

    private UserPojo createUserPojo(String name, String email, String password) {
        UserPojo userPojo = new UserPojo();
        userPojo.setUserName(name);
        userPojo.setEmail(email);
        userPojo.setPassWord(password);
        userPojo.setFavorites(null);

        if (isUserExists(userPojo)) {
            insertUserData(userPojo);
            saveUserData(userPojo);

            Intent intent = new Intent(SignUpActivity.this, HomeForYou.class);
            startActivity(intent);
            SKIP = null;
            finish();
            Toast.makeText(this, "You registered successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "This email already exists", Toast.LENGTH_SHORT).show();
        }
        return userPojo;
    }

    private boolean isEmpty(String text) {
        return text.trim().isEmpty();
    }
@Override
    public boolean isUserExists(UserPojo userPojo) {
        return signupInterface.isUserExists(userPojo);
    }


    @Override
    public void insertUserData(UserPojo userPojo) {
        signupInterface.addUserData(userPojo);
    }


    @Override
    public void saveUserData(UserPojo userPojo) {
        signupInterface.saveUserData(userPojo);
    }

    @Override
    public void handleSignInResult(@NonNull Task<GoogleSignInAccount> completedTask) throws ApiException {

    }

    @Override
    public void SignUpWithGoogle(@NonNull GoogleSignInAccount account) {

    }

    @Override
    public void addUserData(UserPojo userPojo) {

    }
  /*  @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Intent intent = new Intent(this, HomeForYou.class);
            startActivity(intent);
            finish();
        }
        else {
            Intent intent = new Intent(this, EntrancePage.class);
            startActivity(intent);
            finish();
        }
    }*/

}

