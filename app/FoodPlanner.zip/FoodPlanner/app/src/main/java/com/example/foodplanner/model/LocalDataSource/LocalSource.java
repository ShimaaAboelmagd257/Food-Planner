package com.example.foodplanner.model.LocalDataSource;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.Flowable;

public interface LocalSource {

    Completable insertFavorite(ProductsPOJO productpojo);

    Completable removeFavorite(ProductsPOJO productpojo);

    Flowable<List<ProductsPOJO >> getAllStoredFavorites();

    Completable insertPlan(ProductsPOJO productpojo);

    Completable removePlan(ProductsPOJO productpojo);

    Flowable<List<ProductsPOJO >> getAllStoredPlans(String day);

    Completable deleteAllMeals();
}
