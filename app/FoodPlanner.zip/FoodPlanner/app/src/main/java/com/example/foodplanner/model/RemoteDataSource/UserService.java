package com.example.foodplanner.model.RemoteDataSource;

import com.example.foodplanner.model.Pojos.ProductsPOJO;
import com.example.foodplanner.model.Pojos.AreasPojo;
import com.example.foodplanner.model.Pojos.CategoriesPojo;
import com.example.foodplanner.model.Pojos.IngeriedientPojo;

import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.core.Single;
import retrofit2.http.GET;
import retrofit2.http.Query;

//Define the Endpoints
public interface UserService {
    @GET("search.php")
    Single<ProductsPOJO> getMealByName (@Query("s") String name);

    @GET("search.php")
    Single<ProductsPOJO> getMealByFirstChar (@Query("f") String name);

   @GET("lookup.php")
    Single<ProductsPOJO> getMealByID (@Query("d") String name);

    @GET("filter.php")
    Single<ProductsPOJO> getMealsByCategory(@Query("c") String category);

    @GET("filter.php")
    Single<ProductsPOJO> getMealsByArea(@Query("a") String country);

    @GET("filter.php")
    Single<ProductsPOJO> getMealsByIngredient(@Query("i") String ingredient);

   @GET("random.php")
    Flowable<ProductsPOJO> getRandomMeal ();

   @GET("categories.php")
    Single<CategoriesPojo> getAllCategories();

   @GET("list.php?a=list")
    Single<AreasPojo> getAllAreas();

    @GET("list.php?i=list")
    Single<IngeriedientPojo> getAllIngredients();


}
