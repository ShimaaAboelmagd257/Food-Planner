package com.example.foodplanner.model.Pojos;

import java.util.List;

public class AreasPojo {


    private List<AreasPojo> area;

    private String strArea;


    public String getStrArea() {
        return strArea;
    }

    public void setStrArea(String strArea) {
        this.strArea = strArea;
    }

    public List<AreasPojo> getArea() {
        return area;
    }

    public void setArea(List<AreasPojo> area) {
        this.area = area;
    }


}
