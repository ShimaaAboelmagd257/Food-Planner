package com.example.foodplanner.search.searchcategory.view;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

public interface CategoryResponce {

    void ViewCategoryMeal(List<ProductsPOJO> models);
    void addToFavorite (ProductsPOJO mealModel);

}
