package com.example.foodplanner.authantication.signup.view;

import androidx.annotation.NonNull;

import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public interface SignUpInterface {


    void insertUserData(UserPojo userPojo);

    boolean isUserExists(UserPojo userPojo);

    void saveUserData(UserPojo userPojo);

    void handleSignInResult(@NonNull Task<GoogleSignInAccount> completedTask) throws ApiException;

    void SignUpWithGoogle(@NonNull GoogleSignInAccount account);


    void addUserData(UserPojo userPojo);
}

