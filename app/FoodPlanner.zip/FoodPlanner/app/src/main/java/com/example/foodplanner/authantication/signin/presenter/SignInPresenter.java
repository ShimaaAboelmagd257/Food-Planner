package com.example.foodplanner.authantication.signin.presenter;

import android.content.Context;

import com.example.foodplanner.authantication.signin.view.SignInInterface;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.FirebaseRepo;
import com.example.foodplanner.dataBaseHandling.Model.firebase.LoginCallBack;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;

public class SignInPresenter implements SignInPresenterInterface {
    private FirebaseRepo repo;

    private SignInInterface view;

    public SignInPresenter(SignInInterface view, FirebaseRepo repo){
        repo=repo;
        view=view;
    }

    @Override
    public void addUserDataToShered(UserPojo userPojo) {
        repo.saveUserData(userPojo);
    }

    @Override
    public boolean checkUserData(Context context, String email, String pass , LoginCallBack callBack) {
        return repo.isLoginSuccessed(context,email,pass , callBack);
    }



}
