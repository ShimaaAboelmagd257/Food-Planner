package com.example.foodplanner.dataBaseHandling.Model.Reposatory;

import android.content.Context;

import com.example.foodplanner.dataBaseHandling.Model.firebase.FireBaseDataHandle;
import com.example.foodplanner.dataBaseHandling.Model.firebase.LoginCallBack;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserExistCallback;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;
import com.example.foodplanner.model.sharedprefrence.SharedPreference;

public class FirebaseRepository implements FirebaseRepo {
    private  SharedPreference sharedPreference;
    private Context context;
    private FireBaseDataHandle firebaseSource;
    LoginCallBack loginCallBack;
    UserExistCallback userExistCallback;
    //private SharedPreferenceSource sharedPreferenceSource;
   private static FirebaseRepository repository = null;

    public FirebaseRepository(FireBaseDataHandle firebaseSource, SharedPreference sharedPreference, Context context) {
        this.context = context;
        this.sharedPreference = sharedPreference ;
        this.firebaseSource = firebaseSource;

    }



    public static FirebaseRepository getInstance(FireBaseDataHandle firebaseSource, SharedPreference sharedPreference,Context context){
        if (repository == null){
            repository = new FirebaseRepository(firebaseSource , sharedPreference, context);
        }

        return  repository;
    }

    @Override
    public void SignUpWithGoogle(UserPojo userPojo) {

    }

    @Override
    public void signUpWithCreateEmail(UserPojo userPojo) {
        firebaseSource.insertUser(userPojo);
    }



    @Override
    public void saveUserData(UserPojo userPojo) {
        sharedPreference.saveUserData(userPojo);
    }

    @Override
    public boolean isUserExists(UserPojo userPojo) {
        return false;
    }

    @Override
    public boolean isUserExists(boolean exists) {

        return userExistCallback.onUserExists(exists);
    }

    @Override
    public boolean isLoginSuccessed(Context context, String email, String pass , final  LoginCallBack callBack) {

        return firebaseSource.login(context,email,pass,callBack);
    }

    @Override
    public UserPojo  getSavedUserData() {
        return sharedPreference.getSavedUserData();
    }

    @Override
    public void updateUserData(UserPojo userPojo) {
        sharedPreference.updateUserData(userPojo);
    }

    @Override
    public void updateUserFirebaseData(UserPojo userPojo) {
        firebaseSource.insertUser(userPojo);
    }

    @Override
    public void updateFavoriteInFirebase(UserPojo userPojo) {
        firebaseSource.insertUser(userPojo);
    }

    @Override
    public void uploadPlanInFirebase(UserPojo userPojo) {
        firebaseSource.insertUser(userPojo);
    }


}
