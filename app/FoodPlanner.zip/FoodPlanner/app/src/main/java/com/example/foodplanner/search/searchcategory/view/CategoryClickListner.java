package com.example.foodplanner.search.searchcategory.view;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

public interface CategoryClickListner {
    void addToFavoriteOnClick(ProductsPOJO mealModel);
}
