package com.example.foodplanner.authantication.signup.presenter;

import com.example.foodplanner.authantication.signup.view.SignUpInterface;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.FirebaseRepo;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;

public class SignUpresenter implements SignUpresenrterInterface {

    private FirebaseRepo repo;

    private SignUpInterface view;

    public SignUpresenter(FirebaseRepo repo){
        this.repo = repo;

    }

    @Override
    public void onSuccessSignUpWithGoogle() {

    }

    @Override
    public void onFailureSignUpWithGoogle(String error) {

    }

    @Override
    public void addUserData(UserPojo userPojo) {
        repo.signUpWithCreateEmail(userPojo);
    }


    @Override
    public void saveUserData(UserPojo userPojo) {
        repo.saveUserData(userPojo);
    }


    @Override
    public boolean isUserExists(UserPojo userPojo) {
        return repo.isUserExists(userPojo);
    }
}


