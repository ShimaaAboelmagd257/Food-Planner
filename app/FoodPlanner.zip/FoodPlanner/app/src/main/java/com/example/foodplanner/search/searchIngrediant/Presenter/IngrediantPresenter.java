package com.example.foodplanner.search.searchIngrediant.Presenter;

public class IngrediantPresenter {
}
