package com.example.foodplanner.search.searchIngrediant.Presenter;

public interface IngredientPresnterInterface {
}
