package com.example.foodplanner.splashEntrance.presenter;

public class EntrancePresenter {
}
