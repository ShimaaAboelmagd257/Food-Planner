package com.example.foodplanner.utility.NetworkConnectionWIFI;

public interface NetworkStateListner {
    void  onNetworkAvailable();
    void onNetworkUnavailable();
}
