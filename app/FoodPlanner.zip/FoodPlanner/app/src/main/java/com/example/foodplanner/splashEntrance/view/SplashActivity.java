package com.example.foodplanner.splashEntrance.view;

import static androidx.fragment.app.FragmentManager.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.example.foodplanner.R;
import com.google.firebase.FirebaseApp;

public class SplashActivity extends AppCompatActivity {
    private LottieAnimationView lottieAnimationView;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        Toast.makeText(SplashActivity.this, "Loading...", Toast.LENGTH_SHORT).show();
        lottieAnimationView = findViewById(R.id.animationView);
        new Handler().postDelayed(() -> {
            lottieAnimationView.setAnimation("food.json"); // Set the JSON file
            lottieAnimationView.playAnimation(); // Start the animation

        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        }, 6000);


       /* try {
            // Attempt to load the Lottie animation
            LottieComposition.Factory.fromAssetFileName(this, "food.json", new OnCompositionLoadedListener() {
                @Override
                public void onCompositionLoaded(@Nullable LottieComposition composition) {
                    if (composition != null) {
                        animationView.setComposition(composition);
                        animationView.playAnimation();

                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(SplashActivity.this, "error", Toast.LENGTH_SHORT).show();        }*/

    }

}