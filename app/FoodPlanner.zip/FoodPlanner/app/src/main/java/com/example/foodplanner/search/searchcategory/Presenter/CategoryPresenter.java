package com.example.foodplanner.search.searchcategory.Presenter;

import com.example.foodplanner.model.RemoteDataSource.NetworkDelegate;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.RepoInterface;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.Repository;
import com.example.foodplanner.model.Pojos.AreasPojo;
import com.example.foodplanner.model.Pojos.CategoriesPojo;
import com.example.foodplanner.model.Pojos.IngeriedientPojo;
import com.example.foodplanner.model.Pojos.ProductsPOJO;
import com.example.foodplanner.search.searchcategory.view.CategoryResponce;
import com.example.foodplanner.search.searchcategory.view.CategorySection;

import java.util.List;

public class CategoryPresenter implements CategoryPresenterInterface , NetworkDelegate {

    CategoryResponce view;
    RepoInterface repo;

    public CategoryPresenter(CategorySection view, Repository repo){
        this.repo=repo;
        this.view=view;

    }
    @Override
    public void onSuccessMeals(List<ProductsPOJO> productsPOJO) {
        view.ViewCategoryMeal(productsPOJO);

    }

    @Override
    public void onSuccessCategories(List<CategoriesPojo> categoriesPojo) {


    }

    @Override
    public void onSuccessArea(List<AreasPojo> areasPojo) {

    }

    @Override
    public void onSuccessIngeriedient(List<IngeriedientPojo> ingeriedientPojo) {

    }

    @Override
    public void onfailure(String message) {

    }

    @Override
    public void getMeals(String categories) {

    }

    @Override
    public void addToFavorite(ProductsPOJO mealModel) {

    }
}
