package com.example.foodplanner.model.LocalDataSource;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

import io.reactivex.rxjava3.core.Flowable;

@Dao
public interface DataAcessObjectDAO {

    // for favorite
    @Query("SELECT * From Meals where isFavorite = '1'")
    Flowable<List<ProductsPOJO>> getFavorites() ;
    @Insert
    void insertFavorite (ProductsPOJO productpojo);
    @Delete
    void deleteFavorite (ProductsPOJO productpojo);

    @Query("SELECT * From Meals where nameDay =:day")
    Flowable<List<ProductsPOJO>> getPlans(String day) ;

    //for plans
    @Insert
    void insertPlan (ProductsPOJO productpojo);
    @Delete
    void deletePlan (ProductsPOJO productpojo);

    //all
    @Query("DELETE FROM Meals")
    void deleteAllMeals() ;
    @Update
    void updateMeal(ProductsPOJO productpojo);


}
