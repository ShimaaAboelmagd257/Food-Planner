package com.example.foodplanner.search.searchcountry.view;

public class CountryAdapter {
}
