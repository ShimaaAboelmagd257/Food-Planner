package com.example.foodplanner.authantication.signin.view;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.foodplanner.R;
import com.example.foodplanner.homeforyou.HomeForYou;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import io.reactivex.rxjava3.annotations.NonNull;


public class SignInActivity extends AppCompatActivity implements SignInInterface {

    EditText email,password;
    Button loginBtn , backBtn;
    String userEmail , userPassword;
    ProgressBar progressBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        progressBar.setVisibility(View.VISIBLE);
        email    = findViewById(R.id.EmaiID);
        password = findViewById(R.id.paswordID);
        loginBtn = findViewById(R.id.loginbtnID);
        backBtn  = findViewById(R.id.backBtnID);
        progressBar = findViewById(R.id.progressBar);

        loginBtn.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                userEmail=email.getText().toString();
                userPassword = password.getText().toString();

                if(email.getText().toString().equals("")||email.getText().toString().equals(null))
                    Toast.makeText(SignInActivity.this, "Please fill all data", Toast.LENGTH_SHORT).show();


                else if(password.getText().toString().equals("")||password.getText().toString().equals(null))
                    Toast.makeText(SignInActivity.this, "Please fill all data", Toast.LENGTH_SHORT).show();


                else
                    signInWithEmailAndPassword(userEmail,userPassword);

            }
        });

    }
    @Override
    public void signInWithEmailAndPassword(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                   // @SuppressLint("RestrictedApi")
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                          //  Log.d(TAG, "signInWithEmail:success");
                            Toast.makeText(SignInActivity.this, "Authentication successful.",
                                    Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SignInActivity.this, HomeForYou.class);
                            startActivity(intent);
                            finish();
                        } else {

                           // Log.w(TAG, "signInWithEmail:failure", task.getException());
                            Toast.makeText(SignInActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    @Override
    protected void onStart() {
        super.onStart();
       if (mAuth != null){
           Intent intent = new Intent(this, HomeForYou.class);
           startActivity(intent);
           finish();
       }


    }

    public void showProgress() {
        progressBar.setVisibility(View.VISIBLE);
    }

    public void hideProgress() {
        progressBar.setVisibility(View.GONE);
    }
}