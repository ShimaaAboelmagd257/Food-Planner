package com.example.foodplanner.splashEntrance.view;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodplanner.R;
import com.example.foodplanner.authantication.signin.presenter.SignInPresenterInterface;
import com.example.foodplanner.authantication.signup.presenter.SignUpresenter;
import com.example.foodplanner.authantication.signup.view.SignUpActivity;
import com.example.foodplanner.authantication.signup.view.SignUpInterface;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.FirebaseRepository;
import com.example.foodplanner.dataBaseHandling.Model.firebase.FireBaseDataHandle;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;
import com.example.foodplanner.homeforyou.HomeForYou;
import com.example.foodplanner.model.sharedprefrence.SharedPreference;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.annotations.Nullable;

public class EntrancePage extends AppCompatActivity implements SignUpInterface {

    Button skipBtn , facebookBtn , googleBtn , signupBtn ;
     FirebaseAuth mAuth;
   // GoogleSignInClient googleSignInAccount;
    GoogleSignInClient googleSignInClient;
    private static final int REQ_ONE_TAP = 1;  // Can be any integer unique to the Activity.
    private static final int RC_SIGN_IN=1;
  SignUpInterface signUpInterface;
SignInPresenterInterface signInPresenterInterface;
    protected void onCreate(Bundle savedInstanceState, Context context) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrance_page);
        getSupportActionBar().hide();

        skipBtn = findViewById(R.id.skipBtnID);
        facebookBtn = findViewById(R.id.facbookID);
        googleBtn = findViewById(R.id.googleID);
        signupBtn = findViewById(R.id.signUpBtnID);
        FirebaseApp.initializeApp(this);
        GoogleSignInOptions googleSignInOptions=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken((getString(R.string.default_web_client_id)))
                .requestEmail()
                .build();
        mAuth=FirebaseAuth.getInstance();

         googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);
        googleSignInClient.revokeAccess();
        googleBtn.setOnClickListener(v -> {

                Intent intent = googleSignInClient.getSignInIntent();
                startActivityForResult(intent,RC_SIGN_IN);

        });


        signInPresenterInterface = (SignInPresenterInterface) new SignUpresenter(FirebaseRepository.getInstance(FireBaseDataHandle.getInstance(this)
                , SharedPreference.getInstance(this),this));

        signupBtn.setOnClickListener( v -> {
            Intent intent = new Intent(EntrancePage.this, SignUpActivity.class);
            startActivity(intent);
        });


        skipBtn.setOnClickListener( v -> {
                Intent intent = new Intent(EntrancePage.this, HomeForYou.class);
                startActivity(intent);
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    SignUpWithGoogle(account);
                }
            } catch (ApiException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void handleSignInResult(@androidx.annotation.NonNull Task<GoogleSignInAccount> completedTask) throws ApiException {
        System.out.println("Hello from handleSignInResult Auth........");
        GoogleSignInAccount acc=completedTask.getResult(ApiException.class);
        // System.out.println("SignIn Successfully ");
        Toast.makeText(this, "SignIn Successfully", Toast.LENGTH_SHORT).show();
        SignUpWithGoogle(acc);

    }

    @Override
    public void addUserData(UserPojo userPojo) {


    }


    /*BeginSignInRequest signInRequest = BeginSignInRequest.builder()
            .setGoogleIdTokenRequestOptions(BeginSignInRequest.GoogleIdTokenRequestOptions.builder()
            .setSupported(true)
    // Your server's client ID, not your Android client ID.
            .setServerClientId(getString(R.string.default_web_client_id))
            // Only show accounts previously used to sign in.
            .setFilterByAuthorizedAccounts(true)
            .build())
            .build();*/


    @Override
    public  void SignUpWithGoogle(@androidx.annotation.NonNull GoogleSignInAccount account){


        AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        mAuth.signInWithCredential(firebaseCredential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(EntrancePage.this, " Signin with Google succeded", Toast.LENGTH_SHORT).show();

                        FirebaseUser user = mAuth.getCurrentUser();
                        if(user!=null){
                            UserPojo userPojo = createUserPojoFromFirebaseUser(user);
                            saveUserData(userPojo);
                            Toast.makeText(EntrancePage.this, "Signed Successfully", Toast.LENGTH_SHORT).show();
                            navigateToHomeActivity();
                        }
                    }
                });
    }



    @Override
    public void insertUserData(UserPojo userPojo) {
        signUpInterface.insertUserData(userPojo);
    }

    @Override
    public boolean isUserExists(UserPojo userPojo) {
        return signUpInterface.isUserExists(userPojo);
    }
    @Override
    public void saveUserData(UserPojo userPojo) {
        signUpInterface.saveUserData(userPojo);
    }

    private UserPojo createUserPojoFromFirebaseUser(FirebaseUser user) {
        UserPojo userPojo = new UserPojo();
        userPojo.setUserName(user.getDisplayName());
        userPojo.setEmail(user.getEmail());
        userPojo.setImage(user.getPhotoUrl().toString());
        userPojo.setFavorites(null);
        return userPojo;
    }

    private void  navigateToHomeActivity() {
        Intent intent = new Intent(EntrancePage.this, HomeForYou.class);
        startActivity(intent);
        finish();
    }


}