package com.example.foodplanner.search.searchIngrediant.view;

public class IngreduentAdapter {
}
