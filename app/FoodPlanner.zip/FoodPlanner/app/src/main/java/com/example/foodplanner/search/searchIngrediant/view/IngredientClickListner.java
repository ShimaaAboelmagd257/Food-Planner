package com.example.foodplanner.search.searchIngrediant.view;

public interface IngredientClickListner {
}
