package com.example.foodplanner.search.searchcountry.Presenter;

public interface CountryPreseneterInterface {
}
