package com.example.foodplanner.dataBaseHandling.Model.Reposatory;

import android.content.Context;

import com.example.foodplanner.model.RemoteDataSource.ApiClient;
import com.example.foodplanner.model.RemoteDataSource.NetworkDelegate;
import com.example.foodplanner.model.RemoteDataSource.RemoteSource;
import com.example.foodplanner.model.LocalDataSource.ConcreteLocalSource;
import com.example.foodplanner.model.LocalDataSource.LocalSource;
import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

import io.reactivex.rxjava3.core.Flowable;

public class Repository implements RepoInterface {

    private Context context ;
    private RemoteSource remoteSource;
    private LocalSource localSource;
    private static Repository instance = null;

    public Repository(ApiClient remoteSource, ConcreteLocalSource localSource, Context context) {
        this.context = context;
        this.remoteSource = remoteSource;
        this.localSource = localSource;
    }


    public static Repository getInstance(ApiClient remoteSource, ConcreteLocalSource localSource, Context context){
        if (instance == null){
            instance = new Repository(remoteSource,localSource,context);
        }

        return  instance;
    }

    @Override
    public void getRandomMeal(NetworkDelegate networkDelegate) {
        remoteSource.getRandomMeal(networkDelegate);
    }

    @Override
    public void getAllCategories(NetworkDelegate networkDelegate) {
        remoteSource.getAllCategories(networkDelegate);
    }

    @Override
    public void getAllCountries(NetworkDelegate networkDelegate) {
        remoteSource.getAllAreas(networkDelegate);
    }

    @Override
    public void getAllIngredient(NetworkDelegate networkDelegate) {
        remoteSource.getAllIngredients(networkDelegate);
    }

    @Override
    public void getMealsByName(NetworkDelegate networkDelegate, String name) {
        remoteSource.getMealByName(networkDelegate,name);
    }

    @Override
    public void getMealsByFirstChar(NetworkDelegate networkDelegate, String name) {
        remoteSource.getMealByFirstChar(networkDelegate,name);
    }

    @Override
    public void getMealsByCategories(NetworkDelegate networkDelegate, String category) {
        remoteSource.getMealsByCategory(networkDelegate,category);
    }

    @Override
    public void getMealsByCountries(NetworkDelegate networkDelegate, String country) {
        remoteSource.getMealsByArea(networkDelegate,country);
    }

    @Override
    public void getMealsByIngredients(NetworkDelegate networkDelegate, String ingredient) {
        remoteSource.getMealsByIngredient(networkDelegate,ingredient);
    }

    @Override
    public void insertFavorite(ProductsPOJO mealModel) {
        localSource.insertFavorite(mealModel);
    }

    @Override
    public void removeFavorite(ProductsPOJO mealModel) {
        localSource.removeFavorite(mealModel);
    }

    @Override
    public Flowable<List<ProductsPOJO>> getAllStoredFavorites() {
        return localSource.getAllStoredFavorites();
    }

    @Override
    public void insertPlan(ProductsPOJO mealModel) {
        localSource.insertPlan(mealModel);

    }

    @Override
    public void removePlan(ProductsPOJO mealModel) {
        localSource.removePlan(mealModel);

    }

    @Override
    public Flowable<List<ProductsPOJO>> getAllStoredPlans(String day) {
        return localSource.getAllStoredPlans(day);
    }

    @Override
    public void deleteAllMeals() {
        localSource.deleteAllMeals();
    }

    @Override
    public void insertDataInRoom(ProductsPOJO mealModel) {
        localSource.insertFavorite(mealModel);
    }

    //public void getRandomMeal(HomePagePresenter homePagePresenter) {}

    }










