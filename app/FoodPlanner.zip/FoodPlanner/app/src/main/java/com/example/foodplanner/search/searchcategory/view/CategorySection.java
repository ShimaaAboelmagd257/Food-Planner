package com.example.foodplanner.search.searchcategory.view;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foodplanner.R;
import com.example.foodplanner.model.RemoteDataSource.ApiClient;
import com.example.foodplanner.dataBaseHandling.Model.Reposatory.Repository;
import com.example.foodplanner.model.LocalDataSource.ConcreteLocalSource;
import com.example.foodplanner.model.Pojos.ProductsPOJO;
import com.example.foodplanner.search.searchcategory.Presenter.CategoryPresenter;

import java.util.ArrayList;
import java.util.List;


public class CategorySection extends Fragment implements CategoryResponce , CategoryClickListner {

    RecyclerView recyclerView;
    TextView textView ;
    GridLayoutManager gridLayoutManager;
    String categoryMealName;
    CategoryAdapter CategoryAdapter;
    CategoryPresenter categoryPresenter;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_category_section, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view , savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerCategory);
        textView = view.findViewById(R.id.categoryText);

        if (categoryMealName != null) {
            textView.setText(categoryMealName);
        }


        gridLayoutManager=new GridLayoutManager(getContext(),2);
        categoryPresenter= new CategoryPresenter(this, Repository.getInstance(ApiClient.getInstance(getContext()), ConcreteLocalSource.getInstance(getContext()),view.getContext()));
        CategoryAdapter=new CategoryAdapter(getContext(),new ArrayList<>(),this);
        recyclerView.setAdapter(CategoryAdapter);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);

        categoryPresenter.getMeals(categoryMealName);
    }

    @Override
    public void ViewCategoryMeal(List<ProductsPOJO> models) {
        CategoryAdapter.setList(models);
        CategoryAdapter.notifyDataSetChanged();

    }

    @Override
    public void addToFavorite(ProductsPOJO mealModel) {
        categoryPresenter.addToFavorite(mealModel);

    }

    @Override
    public void addToFavoriteOnClick(ProductsPOJO mealModel) {
         addToFavorite(mealModel);
        Toast.makeText(getContext(),"Meal added to favorite",Toast.LENGTH_SHORT).show();
    }
}