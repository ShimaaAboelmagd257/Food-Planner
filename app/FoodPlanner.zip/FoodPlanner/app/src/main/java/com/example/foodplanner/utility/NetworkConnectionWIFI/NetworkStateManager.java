package com.example.foodplanner.utility.NetworkConnectionWIFI;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;

import java.util.ArrayList;
import java.util.List;

public class NetworkStateManager extends ConnectivityManager.NetworkCallback {

    private ConnectivityManager connectivityManager;
    private List<NetworkStateListner> networkStateListners;

    public NetworkStateManager(Context context){

        connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        networkStateListners = new ArrayList<>();
    }
    public void addListener(NetworkStateListner listener) {
        networkStateListners.add(listener);
    }

    public void removeListener(NetworkStateListner listener) {
        networkStateListners.remove(listener);
    }

    public void startMonitoring() {
        NetworkRequest networkRequest = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
        connectivityManager.registerNetworkCallback(networkRequest, this);
    }

    public void stopMonitoring() {
        connectivityManager.unregisterNetworkCallback(this);
    }

    @Override
    public void onAvailable(Network network) {
        notifyNetworkAvailable();
    }

    @Override
    public void onLost(Network network) {
        notifyNetworkUnavailable();
    }


    private void notifyNetworkAvailable() {
        for (NetworkStateListner listener : networkStateListners) {
            listener.onNetworkAvailable();
        }
    }

    private void notifyNetworkUnavailable() {
        for (NetworkStateListner listener : networkStateListners) {
            listener.onNetworkUnavailable();
        }
    }
}
