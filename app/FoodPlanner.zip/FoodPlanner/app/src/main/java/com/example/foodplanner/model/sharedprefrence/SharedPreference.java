package com.example.foodplanner.model.sharedprefrence;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;

public class SharedPreference implements  SharedPrefrenceInterface{



    private static SharedPreference sharedPreferenceInstance = null;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private UserPojo userPojo ;
    public static final String SHARDPREFERENCE = "SharedPreference";
    public static final String USERNAME = "USERNAME";
    public static final String EMAIL = "EMAIL";
    public static final String PASSWORD = "PASSWORD";
    public static final String IMAGE = "IMAGE";


    public SharedPreference(Context context) {

        sharedPreferences = context.getSharedPreferences( SHARDPREFERENCE , context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
         userPojo = new UserPojo();


    }

    public static SharedPreference getInstance(Context context){

    if(sharedPreferenceInstance == null){
        sharedPreferenceInstance =  new SharedPreference(context);

    }
    return sharedPreferenceInstance;

}



    @Override
    public void saveUserData(UserPojo userPojo) {
        editor.putString(USERNAME,userPojo.getUserName());
        editor.putString(PASSWORD,userPojo.getPassWord());
        editor.putString(EMAIL,userPojo.getEmail());
        editor.commit();


    }


    @Override
    public UserPojo getSavedUserData() {
        userPojo.setUserName(sharedPreferences.getString(USERNAME,"Null"));
        userPojo.setEmail(sharedPreferences.getString(EMAIL,"Null"));
        userPojo.setPassWord(sharedPreferences.getString(PASSWORD,"Null"));
        userPojo.setImage(sharedPreferences.getString(IMAGE,"null"));
        return userPojo;


    }

    @Override
    public void updateUserData( UserPojo userPojo) {
        editor.putString(USERNAME,userPojo.getUserName());
        editor.putString(PASSWORD,userPojo.getPassWord());
        editor.putString(EMAIL,userPojo.getEmail());
        editor.putString(IMAGE,userPojo.getImage());
        editor.commit();

    }

}
