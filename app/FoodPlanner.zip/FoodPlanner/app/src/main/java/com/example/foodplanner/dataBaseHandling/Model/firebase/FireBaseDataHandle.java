package com.example.foodplanner.dataBaseHandling.Model.firebase;

import android.content.Context;

import java.util.Arrays;
import java.util.List;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class FireBaseDataHandle {

    private static FireBaseDataHandle instance = null; // to apply the singleton
    private DatabaseReference databaseReference; // a class in firebase extends Query to handle the Querys

    public FireBaseDataHandle(Context context) {
        databaseReference = FirebaseDatabase.getInstance().getReference();
    }

    public static FireBaseDataHandle getInstance (Context context){
        if (instance == null){

            instance = new FireBaseDataHandle(context);
        }
         return instance;
    }

    public void insertUser(UserPojo userPojo) {
        List<String> route = Arrays.asList(userPojo.getEmail().split("\\."));
        databaseReference.child("User").child(route.get(0)).setValue(userPojo);
    }






    public void checkUserExists(UserPojo userModel, final UserExistCallback callback) {
        List<String> route = Arrays.asList(userModel.getEmail().split("\\."));
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("User");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                UserPojo existingUser = dataSnapshot.child(route.get(0)).getValue(UserPojo.class);
                boolean exists = false;

                if (existingUser != null && existingUser.getEmail().equals(userModel.getEmail())) {
                    exists = true;
                }

                callback.onUserExists(exists);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                callback.onUserExistsCheckFailure("Database error occurred.");
            }
        });
    }
    public boolean login(Context context, String email, String password, final LoginCallBack callback) {
        String[] splitEmail = email.split("\\.");
        String root = splitEmail[0];

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("User");
        databaseReference.child(root).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    UserPojo userModel = snapshot.getValue(UserPojo.class);

                     if (userModel != null) {

                          if (userModel.getPassWord().equals(password) && userModel.getEmail().equals(email)) {
                           // showDataFromFirebase(userModel);
                           // SharedPreferenceSource.getInstance(context).saveUserData(userModel);
                            callback.onLoginSuccess();
                          }
                        else
                            callback.onLoginFailure("Invalid email or password.");

                     }
                    else
                        callback.onLoginFailure("User data is invalid.");

                }
                else
                    callback.onLoginFailure("User not found.");

            }

            @Override
            public void onCancelled( DatabaseError error) {
                callback.onLoginFailure("Database error occurred.");
            }
        });
        return false;
    }



}
