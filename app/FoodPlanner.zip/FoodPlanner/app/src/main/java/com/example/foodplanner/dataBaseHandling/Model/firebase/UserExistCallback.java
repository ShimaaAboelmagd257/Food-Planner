package com.example.foodplanner.dataBaseHandling.Model.firebase;

public interface UserExistCallback {
    boolean onUserExists(boolean exists);
    void onUserExistsCheckFailure(String errorMessage);
}
