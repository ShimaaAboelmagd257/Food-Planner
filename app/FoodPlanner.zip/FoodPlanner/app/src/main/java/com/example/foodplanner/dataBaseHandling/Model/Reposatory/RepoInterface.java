package com.example.foodplanner.dataBaseHandling.Model.Reposatory;

import com.example.foodplanner.model.RemoteDataSource.NetworkDelegate;
import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

import io.reactivex.rxjava3.core.Flowable;

public interface RepoInterface {
    void getRandomMeal(NetworkDelegate networkDelegate);

    void getAllCategories(NetworkDelegate networkDelegate);

    void getAllCountries(NetworkDelegate networkDelegate);

    void getAllIngredient(NetworkDelegate networkDelegate);

    void getMealsByName(NetworkDelegate networkDelegate, String name);

    void getMealsByFirstChar(NetworkDelegate networkDelegate, String name);

    void getMealsByCategories(NetworkDelegate networkDelegate, String category);

    void getMealsByCountries(NetworkDelegate networkDelegate, String country);

    void getMealsByIngredients(NetworkDelegate networkDelegate, String ingredient);

    void insertFavorite(ProductsPOJO mealModel);

    void removeFavorite(ProductsPOJO mealModel);

    Flowable<List<ProductsPOJO>> getAllStoredFavorites();

    void insertPlan(ProductsPOJO mealModel);

    void removePlan(ProductsPOJO mealModel);

    Flowable<List<ProductsPOJO>> getAllStoredPlans(String day);

    void deleteAllMeals();

    void insertDataInRoom(ProductsPOJO mealModel);
}
