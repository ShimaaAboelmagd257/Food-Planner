package com.example.foodplanner.splashEntrance.view;

import static androidx.fragment.app.FragmentManager.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.foodplanner.R;
import com.example.foodplanner.authantication.signup.view.SignUpActivity;
import com.example.foodplanner.homeforyou.HomeForYou;
import com.example.foodplanner.utility.NetworkConnectionWIFI.NetworkStateListner;
import com.example.foodplanner.utility.NetworkConnectionWIFI.NetworkStateManager;
import com.google.firebase.FirebaseApp;

public class MainActivity extends AppCompatActivity implements NetworkStateListner {
    private NetworkStateManager networkStateManager;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        /*By passing this as an argument, you establish a connection between the MainActivity and NetworkStateManager,
          enabling the NetworkStateManager to listen for network state changes and notify the MainActivity accordingly.*/
        networkStateManager = new NetworkStateManager(this);
        networkStateManager.addListener(this);
        networkStateManager.startMonitoring();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        networkStateManager.stopMonitoring();
        networkStateManager.removeListener(this);
    }

    @Override
    public void onNetworkAvailable() {
        Toast.makeText(this, "Network is available", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, EntrancePage.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onNetworkUnavailable() {
        Toast.makeText(this, "Network is unavailable", Toast.LENGTH_SHORT).show();
    }
}