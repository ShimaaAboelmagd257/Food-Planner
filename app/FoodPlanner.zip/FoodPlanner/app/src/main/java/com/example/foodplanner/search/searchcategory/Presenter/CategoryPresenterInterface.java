package com.example.foodplanner.search.searchcategory.Presenter;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

public interface CategoryPresenterInterface {

    void getMeals(String categories);

    void addToFavorite(ProductsPOJO mealModel);
}
