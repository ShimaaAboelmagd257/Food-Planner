package com.example.foodplanner.search.searchcountry.view;

public interface CountryResponce {
}
