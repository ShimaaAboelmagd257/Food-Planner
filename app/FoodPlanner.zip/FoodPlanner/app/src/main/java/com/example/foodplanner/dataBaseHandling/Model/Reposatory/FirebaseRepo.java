package com.example.foodplanner.dataBaseHandling.Model.Reposatory;

import android.content.Context;

import com.example.foodplanner.dataBaseHandling.Model.firebase.LoginCallBack;
import com.example.foodplanner.dataBaseHandling.Model.firebase.UserPojo;

public interface FirebaseRepo {
    void SignUpWithGoogle(UserPojo userPojo);

    void signUpWithCreateEmail(UserPojo userPojo);

    void saveUserData(UserPojo userPojo);

    boolean isUserExists(UserPojo userPojo);

    boolean isUserExists(boolean exists);

    boolean isLoginSuccessed(Context context, String email, String pass , final LoginCallBack callBack);

    UserPojo  getSavedUserData();

    void updateUserData(UserPojo userPojo);

    void updateUserFirebaseData(UserPojo userPojo);

    void updateFavoriteInFirebase(UserPojo userPojo);

    void uploadPlanInFirebase(UserPojo userPojo);
}
