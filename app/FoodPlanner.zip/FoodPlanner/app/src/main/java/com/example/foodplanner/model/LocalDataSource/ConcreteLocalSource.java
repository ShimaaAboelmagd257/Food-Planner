package com.example.foodplanner.model.LocalDataSource;

import android.content.Context;

import com.example.foodplanner.model.Pojos.ProductsPOJO;

import java.util.List;

import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.Flowable;



public class ConcreteLocalSource implements LocalSource {


    private DataAcessObjectDAO Dao ;
    Flowable<List<ProductsPOJO>> mealFavorites;
    public static ConcreteLocalSource instance = null;
    private ConcreteLocalSource(Context context){

        ProductDataBase productDataBase = ProductDataBase.getInstance(context);
        Dao = productDataBase.Dao();
        mealFavorites = Dao.getFavorites();

    }

    public static ConcreteLocalSource getInstance(Context context){
        if(instance == null){
            instance  = new ConcreteLocalSource(context);
        }
        return instance;
    }

   @Override
    public Completable insertFavorite(ProductsPOJO productpojo) {
        return Completable.fromAction(() -> Dao.insertFavorite(productpojo));
    }
    @Override
    public Completable removeFavorite(ProductsPOJO productpojo) {
        return Completable.fromAction(() -> Dao.deleteFavorite(productpojo));
    }

    @Override

    public Flowable<List<ProductsPOJO >> getAllStoredFavorites() {
        return Dao.getFavorites();
    }

    @Override

    public Completable insertPlan(ProductsPOJO productpojo) {
        return Completable.fromAction(() -> Dao.insertPlan(productpojo));
    }
    @Override

    public Completable removePlan(ProductsPOJO productpojo) {
        return Completable.fromAction(() -> Dao.deletePlan(productpojo));
    }
    @Override

    public Flowable<List<ProductsPOJO >> getAllStoredPlans(String day) {
        return Dao.getPlans(day);
    }

    @Override

    public Completable deleteAllMeals() {
        return Completable.fromAction(() -> Dao.deleteAllMeals());
    }
}
